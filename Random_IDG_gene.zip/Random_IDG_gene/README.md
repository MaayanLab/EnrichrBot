# IDGene
Once a day EnrichrBot randomly selects an IDG target and tweets:
1. URLs to Harmonizome, Geneshot, ARCHS4, and Pharos.
2. Screen shots of \#1
